# Tanya Iman — Prototype

A working, standalone React prototype of a spiritual/emotional Q&A chatbot
restricted to content from 6 approved websites, built for eventual delivery
as (a) an embed on WordPress and (b) an Android app on Google Play via
Capacitor.

## Run locally
```
npm install
npm run dev       # dev server
npm run build     # production build -> dist/
npm run preview   # preview the production build
```

## What's real vs. mocked in this prototype
See HANDOFF.md (in the parent deliverable folder) for the full breakdown and
next steps: Firebase setup, WhatsApp/SMS OTP integration, swapping the local
keyword-matching answer engine for a real LLM-based RAG pipeline, WordPress
embedding, and Google Play packaging via Capacitor.

## Project structure
- `src/data/knowledgeBase.json` — starter library of real articles scraped
  from the 6 approved sites (title, url, excerpt, topic tags).
- `src/data/sampleAnswers.json` — one pre-written, source-grounded answer per
  topic (25–250 words, uses "Allah" / "Isa Al-Masih", Quran ref first then
  Bible verses) used by the demo answer engine.
- `src/lib/answerEngine.js` — classifies a question into a topic and returns
  an answer + related article links, or a refusal for off-topic questions.
  Replace with a real LLM call in production (see HANDOFF.md).
- `src/lib/dataStore.js` — localStorage-backed persistence for questions,
  likes, and admin answer overrides. Structured to map 1:1 onto Firestore
  collections when you're ready to go live.
- `src/pages/Onboarding.jsx` — login screen (SMS / WhatsApp / Guest) + footer
  privacy policy link.
- `src/pages/Chat.jsx` — the main Q&A chat screen.
- `src/pages/PrivacyPolicy.jsx` — Indonesian privacy policy content.
- `src/pages/Admin.jsx` — admin dashboard (password: `admin123` for the demo,
  see `src/lib/adminConfig.js`).
