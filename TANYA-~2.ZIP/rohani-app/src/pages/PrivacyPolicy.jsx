import { Link } from 'react-router-dom'
import Footer from '../components/Footer.jsx'

export default function PrivacyPolicy() {
  return (
    <div className="screen">
      <div className="container policy-content">
        <Link className="back-link" to="/">&larr; Kembali</Link>
        <h1>Kebijakan Privasi</h1>
        <p>Terakhir diperbarui: 31 Juli 2026</p>

        <p>
          Tanya Iman ("kami") menghargai privasi Anda. Kebijakan ini menjelaskan
          data apa yang kami kumpulkan, bagaimana kami menggunakannya, dan
          pilihan yang Anda miliki.
        </p>

        <h2>1. Data yang Kami Kumpulkan</h2>
        <ul>
          <li>
            <strong>Nomor handphone</strong> — jika Anda masuk menggunakan SMS
            atau WhatsApp, kami menyimpan nomor Anda untuk memverifikasi
            identitas dan mengenali percakapan Anda di kunjungan berikutnya.
          </li>
          <li>
            <strong>Penggunaan sebagai Tamu</strong> — jika Anda memilih
            "Lanjutkan sebagai Tamu", kami tidak mengumpulkan nomor handphone
            atau data identitas pribadi apa pun.
          </li>
          <li>
            <strong>Pertanyaan yang Anda ajukan</strong> — kami menyimpan isi
            pertanyaan dan jawaban yang diberikan agar tim kami dapat
            meninjau kualitas jawaban, menambahkan jawaban baru, dan
            memahami topik yang paling sering ditanyakan.
          </li>
          <li>
            <strong>Interaksi "Suka"</strong> — kami mencatat jawaban mana
            yang Anda tandai sebagai bermanfaat, untuk membantu kami
            meningkatkan kualitas jawaban.
          </li>
        </ul>

        <h2>2. Bagaimana Kami Menggunakan Data</h2>
        <p>
          Data digunakan semata-mata untuk mengoperasikan dan meningkatkan
          layanan ini: memverifikasi masuk, menampilkan riwayat percakapan
          Anda, meninjau dan memperbaiki jawaban melalui panel admin internal,
          serta memahami kebutuhan pengguna secara umum (misalnya topik yang
          paling sering ditanyakan).
        </p>

        <h2>3. Berbagi Data</h2>
        <p>
          Kami tidak menjual data Anda kepada pihak ketiga. Data hanya dapat
          diakses oleh tim admin internal kami dan penyedia layanan teknis
          (seperti penyedia basis data dan penyedia pengiriman kode
          verifikasi SMS/WhatsApp) yang membantu kami mengoperasikan aplikasi
          ini.
        </p>

        <h2>4. Keamanan</h2>
        <p>
          Kami berupaya melindungi data Anda dengan langkah keamanan yang
          wajar. Namun, tidak ada sistem yang sepenuhnya bebas risiko, dan
          kami mendorong Anda untuk tidak membagikan informasi sensitif yang
          tidak diperlukan dalam pertanyaan Anda.
        </p>

        <h2>5. Pilihan Anda</h2>
        <p>
          Anda dapat menggunakan aplikasi ini sebagai Tamu kapan pun untuk
          menghindari penyimpanan nomor handphone Anda. Anda juga dapat
          menghubungi kami untuk meminta penghapusan data pertanyaan yang
          terkait dengan nomor Anda.
        </p>

        <h2>6. Anak-Anak</h2>
        <p>
          Layanan ini ditujukan untuk pengguna umum yang mencari jawaban atas
          pertanyaan rohani dan emosional. Kami tidak secara sengaja
          mengumpulkan data dari anak-anak di bawah usia yang diizinkan
          hukum setempat tanpa persetujuan orang tua atau wali.
        </p>

        <h2>7. Hubungi Kami</h2>
        <p>
          Jika Anda memiliki pertanyaan tentang kebijakan privasi ini,
          silakan hubungi kami melalui menu "Hubungi Kami" di dalam aplikasi.
        </p>
      </div>
      <Footer />
    </div>
  )
}
