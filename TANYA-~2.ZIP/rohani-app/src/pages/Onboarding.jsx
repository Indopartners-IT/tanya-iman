import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Footer from '../components/Footer.jsx'
import { setAuthUser } from '../lib/dataStore.js'

// PRODUCTION NOTE: OTP sending/verification here is fully mocked (any code is
// accepted) so the prototype works standalone without a live backend.
// Replace `sendCode` / `verifyCode` with:
//   - SMS: Firebase Auth `signInWithPhoneNumber` (RecaptchaVerifier + confirm)
//   - WhatsApp: a provider such as Twilio Verify (WhatsApp channel) or the
//     WhatsApp Business Cloud API, since Firebase Auth alone does not send
//     WhatsApp OTPs. Call your backend endpoint, which triggers the provider,
//     then verifies the code server-side before minting a Firebase custom
//     token / session for the user.

export default function Onboarding() {
  const navigate = useNavigate()
  const [method, setMethod] = useState('sms')
  const [phone, setPhone] = useState('')
  const [otp, setOtp] = useState('')
  const [otpSent, setOtpSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  function handleSendCode(e) {
    e.preventDefault()
    setError('')
    if (!phone.trim() || phone.trim().length < 9) {
      setError('Masukkan nomor yang valid, contoh: 08123456789')
      return
    }
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setOtpSent(true)
    }, 600)
  }

  function handleVerify(e) {
    e.preventDefault()
    setError('')
    if (!otp.trim() || otp.trim().length < 4) {
      setError('Masukkan kode verifikasi yang dikirimkan.')
      return
    }
    setLoading(true)
    setTimeout(() => {
      setAuthUser({ phone: phone.trim(), authMethod: method })
      setLoading(false)
      navigate('/chat')
    }, 500)
  }

  function handleGuest() {
    setAuthUser({ phone: null, authMethod: 'guest' })
    navigate('/chat')
  }

  return (
    <div className="screen">
      <div className="container">
        <div className="onboarding-hero">
          <div className="logo-badge">🕊️</div>
          <h1>Selamat Datang di Tanya Iman</h1>
          <p>
            Ajukan pertanyaan tentang kehidupan rohani dan emosional Anda.
            Kami akan menjawab berdasarkan Kitab Suci.
          </p>
        </div>

        <div className="login-card">
          <div className="login-tabs">
            <button
              type="button"
              className={`login-tab ${method === 'sms' ? 'active' : ''}`}
              onClick={() => { setMethod('sms'); setOtpSent(false); setError('') }}
            >
              Masuk dengan SMS
            </button>
            <button
              type="button"
              className={`login-tab ${method === 'whatsapp' ? 'active' : ''}`}
              onClick={() => { setMethod('whatsapp'); setOtpSent(false); setError('') }}
            >
              Masuk dengan WhatsApp
            </button>
          </div>

          {!otpSent ? (
            <form onSubmit={handleSendCode}>
              <label className="field-label" htmlFor="phone">Nomor Handphone</label>
              <input
                id="phone"
                className="text-input"
                type="tel"
                placeholder="Contoh: 08123456789"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
              <p className="helper-text">
                Kami akan mengirimkan kode verifikasi melalui {method === 'sms' ? 'SMS' : 'WhatsApp'}.
              </p>
              {error && <p className="helper-text" style={{ color: '#b23b3b' }}>{error}</p>}
              <button className="btn-primary" type="submit" disabled={loading}>
                {loading ? 'Mengirim kode...' : 'Kirim Kode Verifikasi'}
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerify}>
              <label className="field-label" htmlFor="otp">Kode Verifikasi</label>
              <input
                id="otp"
                className="text-input"
                type="text"
                inputMode="numeric"
                placeholder="Masukkan kode 6 digit"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
              />
              <p className="helper-text">
                Kode telah dikirim ke {phone} melalui {method === 'sms' ? 'SMS' : 'WhatsApp'}.
              </p>
              {error && <p className="helper-text" style={{ color: '#b23b3b' }}>{error}</p>}
              <button className="btn-primary" type="submit" disabled={loading}>
                {loading ? 'Memverifikasi...' : 'Verifikasi & Masuk'}
              </button>
              <button
                className="btn-secondary"
                type="button"
                onClick={() => { setOtpSent(false); setOtp('') }}
              >
                Ganti Nomor
              </button>
            </form>
          )}

          <div className="guest-link">
            <button type="button" onClick={handleGuest}>Lanjutkan sebagai Tamu</button>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
