import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import MessageBubble from '../components/MessageBubble.jsx'
import Footer from '../components/Footer.jsx'
import { buildAnswer } from '../lib/answerEngine.js'
import { logQuestion, toggleLike, getAuthUser, clearAuthUser } from '../lib/dataStore.js'

const GREETING = {
  id: 'greeting',
  role: 'bot',
  text: 'Halo! Selamat datang. Ada yang bisa kami bantu? Silakan tuliskan pertanyaan Anda tentang kehidupan rohani atau emosional Anda.',
  refused: false,
  articles: [],
}

export default function Chat() {
  const navigate = useNavigate()
  const [messages, setMessages] = useState([GREETING])
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef(null)
  const user = getAuthUser()

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, isTyping])

  function handleSubmit(e) {
    e.preventDefault()
    const question = input.trim()
    if (!question) return

    const userMsg = { id: `u_${Date.now()}`, role: 'user', text: question }
    setMessages((prev) => [...prev, userMsg])
    setInput('')
    setIsTyping(true)

    // PRODUCTION NOTE: replace this local buildAnswer() call with a request to
    // your backend (e.g. POST /api/ask), which runs the RAG pipeline against
    // the approved websites and returns { text, articles, topic }.
    setTimeout(() => {
      const result = buildAnswer(question)
      const logged = logQuestion({
        text: question,
        topic: result.topic,
        answerText: result.text,
        articleIds: (result.articles || []).map((a) => a.id),
        refused: result.refused,
      })
      const botMsg = {
        id: logged.id,
        role: 'bot',
        text: result.text,
        refused: result.refused,
        articles: result.articles,
        liked: false,
      }
      setMessages((prev) => [...prev, botMsg])
      setIsTyping(false)
    }, 700)
  }

  function handleLike(messageId) {
    const updated = toggleLike(messageId)
    if (!updated) return
    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, liked: updated.liked } : m)),
    )
  }

  function handleLogout() {
    clearAuthUser()
    navigate('/')
  }

  return (
    <div className="screen">
      <div className="chat-header">
        <h1>Tanya Iman</h1>
        <p className="subtitle">
          {user?.authMethod === 'guest' ? 'Masuk sebagai Tamu' : `Masuk sebagai ${user?.phone || 'Pengguna'}`}
          {' · '}
          <button
            type="button"
            onClick={handleLogout}
            style={{ background: 'none', border: 'none', color: 'white', textDecoration: 'underline', padding: 0, font: 'inherit', cursor: 'pointer' }}
          >
            Keluar
          </button>
        </p>
        <p className="kitab-note">Jawaban di bawah ini berdasarkan Kitab Suci.</p>
      </div>

      <div className="container" style={{ paddingTop: 8 }}>
        <div className="chat-messages" ref={scrollRef}>
          {messages.map((m) => (
            <MessageBubble
              key={m.id}
              role={m.role}
              text={m.text}
              refused={m.refused}
              articles={m.articles}
              liked={m.liked}
              onLike={() => handleLike(m.id)}
            />
          ))}
          {isTyping && <div className="typing-indicator">Sedang mengetik...</div>}
        </div>

        <form className="chat-input-bar" onSubmit={handleSubmit}>
          <textarea
            placeholder="Tulis pertanyaan Anda di sini..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                handleSubmit(e)
              }
            }}
          />
          <button className="send-btn" type="submit" disabled={!input.trim()}>➤</button>
        </form>
      </div>
      <Footer />
    </div>
  )
}
