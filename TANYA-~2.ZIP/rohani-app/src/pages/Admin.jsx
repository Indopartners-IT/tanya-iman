import { useMemo, useState } from 'react'
import {
  getQuestions,
  getTopicCounts,
  getSimilarQuestionGroups,
  getAllAnswerOverrides,
  setAnswerOverride,
} from '../lib/dataStore.js'
import sampleAnswers from '../data/sampleAnswers.json'
import { topicLabel, TOPIC_LABELS } from '../lib/topicLabels.js'
import { ADMIN_PASSWORD } from '../lib/adminConfig.js'

function AdminLogin({ onSuccess }) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    if (password === ADMIN_PASSWORD) {
      sessionStorage.setItem('tanyaiman_admin', '1')
      onSuccess()
    } else {
      setError('Kata sandi salah.')
    }
  }

  return (
    <div className="admin-login">
      <h2 style={{ marginTop: 0 }}>Masuk Admin</h2>
      <form onSubmit={handleSubmit}>
        <label className="field-label" htmlFor="pw">Kata Sandi Admin</label>
        <input
          id="pw"
          className="text-input"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <p className="helper-text" style={{ color: '#b23b3b' }}>{error}</p>}
        <button className="btn-primary" type="submit">Masuk</button>
      </form>
      <p className="helper-text" style={{ marginTop: 12 }}>
        Demo: kata sandi default adalah <code>admin123</code> (lihat src/lib/adminConfig.js).
      </p>
    </div>
  )
}

const EDITABLE_TOPICS = Object.keys(sampleAnswers)

function AnswerEditor({ onSaved }) {
  const [topic, setTopic] = useState(EDITABLE_TOPICS[0])
  const overrides = getAllAnswerOverrides()
  const current = overrides[topic]?.text ?? sampleAnswers[topic]?.text ?? ''
  const [draft, setDraft] = useState(current)
  const [savedTopic, setSavedTopic] = useState(null)

  function handleTopicChange(t) {
    setTopic(t)
    const o = getAllAnswerOverrides()
    setDraft(o[t]?.text ?? sampleAnswers[t]?.text ?? '')
    setSavedTopic(null)
  }

  const wordCount = draft.trim() ? draft.trim().split(/\s+/).length : 0
  const inRange = wordCount >= 25 && wordCount <= 250

  function handleSave() {
    setAnswerOverride(topic, draft)
    setSavedTopic(topic)
    onSaved?.()
  }

  return (
    <div className="answer-editor">
      <select value={topic} onChange={(e) => handleTopicChange(e.target.value)}>
        {EDITABLE_TOPICS.map((t) => (
          <option key={t} value={t}>{topicLabel(t)}</option>
        ))}
      </select>
      <textarea value={draft} onChange={(e) => setDraft(e.target.value)} />
      <div className={`word-count ${inRange ? '' : 'warn'}`}>
        {wordCount} kata {inRange ? '' : '(harus 25–250 kata)'}
      </div>
      <button className="btn-primary" style={{ width: 'auto', padding: '10px 20px' }} onClick={handleSave} disabled={!inRange}>
        Simpan Jawaban
      </button>
      {savedTopic === topic && <span style={{ marginLeft: 10, fontSize: 13, color: 'var(--color-primary)' }}>Tersimpan.</span>}
    </div>
  )
}

export default function Admin() {
  const [authed, setAuthed] = useState(sessionStorage.getItem('tanyaiman_admin') === '1')
  const [, forceRefresh] = useState(0)

  const questions = useMemo(() => getQuestions(), [authed])
  const topicCounts = useMemo(() => getTopicCounts(), [authed])
  const similarGroups = useMemo(() => getSimilarQuestionGroups(), [authed])

  if (!authed) {
    return (
      <div className="screen">
        <div className="container">
          <AdminLogin onSuccess={() => setAuthed(true)} />
        </div>
      </div>
    )
  }

  const totalQuestions = questions.length
  const totalLikes = questions.reduce((sum, q) => sum + (q.likes || 0), 0)
  const totalRefused = questions.filter((q) => q.refused).length
  const uniqueTopics = new Set(questions.map((q) => q.topic)).size

  return (
    <div className="admin-shell">
      <div className="admin-header">
        <h1>Panel Admin — Tanya Iman</h1>
        <button
          className="btn-secondary"
          style={{ width: 'auto' }}
          onClick={() => { sessionStorage.removeItem('tanyaiman_admin'); setAuthed(false) }}
        >
          Keluar
        </button>
      </div>

      <div className="stat-grid">
        <div className="stat-card"><div className="value">{totalQuestions}</div><div className="label">Total Pertanyaan</div></div>
        <div className="stat-card"><div className="value">{totalLikes}</div><div className="label">Total Suka</div></div>
        <div className="stat-card"><div className="value">{totalRefused}</div><div className="label">Di Luar Topik</div></div>
        <div className="stat-card"><div className="value">{uniqueTopics}</div><div className="label">Topik Berbeda</div></div>
      </div>

      <div className="admin-section">
        <h2>Pertanyaan Dikelompokkan per Topik</h2>
        {topicCounts.length === 0 ? (
          <p className="empty-state">Belum ada data. Coba ajukan beberapa pertanyaan di aplikasi.</p>
        ) : (
          <table className="admin-table">
            <thead><tr><th>Topik</th><th>Jumlah Pertanyaan</th></tr></thead>
            <tbody>
              {topicCounts.map((t) => (
                <tr key={t.topic}>
                  <td><span className="badge">{topicLabel(t.topic)}</span></td>
                  <td>{t.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="admin-section">
        <h2>Pertanyaan Serupa (Frekuensi)</h2>
        <p className="helper-text" style={{ marginTop: -4 }}>
          Dikelompokkan berdasarkan kemiripan teks persis. Untuk pengelompokan makna
          yang lebih pintar di produksi, gunakan pencarian semantik/embedding.
        </p>
        {similarGroups.length === 0 ? (
          <p className="empty-state">Belum ada data.</p>
        ) : (
          <table className="admin-table">
            <thead><tr><th>Pertanyaan</th><th>Topik</th><th>Berapa Kali Ditanyakan</th></tr></thead>
            <tbody>
              {similarGroups.slice(0, 20).map((g, i) => (
                <tr key={i}>
                  <td>{g.sample}</td>
                  <td><span className="badge">{topicLabel(g.topic)}</span></td>
                  <td>{g.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="admin-section">
        <h2>Semua Pertanyaan</h2>
        {questions.length === 0 ? (
          <p className="empty-state">Belum ada pertanyaan yang diajukan.</p>
        ) : (
          <table className="admin-table">
            <thead><tr><th>Waktu</th><th>Pengguna</th><th>Pertanyaan</th><th>Topik</th><th>Suka</th></tr></thead>
            <tbody>
              {questions.slice(0, 100).map((q) => (
                <tr key={q.id}>
                  <td>{new Date(q.createdAt).toLocaleString('id-ID')}</td>
                  <td>{q.authMethod === 'guest' ? 'Tamu' : q.userId}</td>
                  <td>{q.text}</td>
                  <td><span className="badge">{topicLabel(q.topic)}</span></td>
                  <td>{q.likes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="admin-section">
        <h2>Tambah / Ubah Jawaban</h2>
        <p className="helper-text" style={{ marginTop: -4 }}>
          Pilih topik lalu ubah teks jawaban. Perubahan langsung berlaku untuk
          jawaban berikutnya pada topik tersebut (harus 25–250 kata).
        </p>
        <AnswerEditor onSaved={() => forceRefresh((n) => n + 1)} />
      </div>
    </div>
  )
}
