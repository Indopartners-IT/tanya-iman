import { Routes, Route, Navigate } from 'react-router-dom'
import Onboarding from './pages/Onboarding.jsx'
import Chat from './pages/Chat.jsx'
import PrivacyPolicy from './pages/PrivacyPolicy.jsx'
import Admin from './pages/Admin.jsx'
import { getAuthUser } from './lib/dataStore.js'

function RequireEntry({ children }) {
  const user = getAuthUser()
  if (!user) return <Navigate to="/" replace />
  return children
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Onboarding />} />
      <Route
        path="/chat"
        element={
          <RequireEntry>
            <Chat />
          </RequireEntry>
        }
      />
      <Route path="/kebijakan-privasi" element={<PrivacyPolicy />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
