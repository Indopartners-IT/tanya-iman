export default function MessageBubble({ role, text, refused, articles, liked, onLike }) {
  const isUser = role === 'user'
  return (
    <div className={`bubble-row ${isUser ? 'user' : 'bot'}`}>
      <div className={`bubble ${refused ? 'refused' : ''}`}>
        {text}
        {!isUser && !refused && articles && articles.length > 0 && (
          <div className="article-links">
            <div className="label">Baca Selengkapnya:</div>
            {articles.map((a) => (
              <a key={a.id} href={a.url} target="_blank" rel="noreferrer">
                {a.title} ({a.site})
              </a>
            ))}
          </div>
        )}
      </div>
      {!isUser && !refused && (
        <div className="bot-actions">
          <button
            type="button"
            className={`like-btn ${liked ? 'liked' : ''}`}
            onClick={onLike}
          >
            {liked ? '👍 Disukai' : '👍 Suka'}
          </button>
        </div>
      )}
    </div>
  )
}
