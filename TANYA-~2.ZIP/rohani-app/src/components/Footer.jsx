import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="app-footer">
      <div>&copy; {new Date().getFullYear()} Tanya Iman.</div>
      <div>
        <Link to="/kebijakan-privasi">Kebijakan Privasi</Link>
      </div>
    </footer>
  )
}
