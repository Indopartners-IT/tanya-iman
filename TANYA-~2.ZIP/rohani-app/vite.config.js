import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
// base: './' so the built assets work when embedded via WordPress (relative paths)
// and when wrapped by Capacitor for the Android/Play Store build.
export default defineConfig({
  plugins: [react()],
  base: './',
})
